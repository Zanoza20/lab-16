var main = document.createElement('main');
main.setAttribute('class', 'mainClass check item');

var div = document.createElement('div');
div.setAttribute('id', 'myDiv');

var paragraph = document.createElement('p');
paragraph.textContent = 'First paragraph';

div.appendChild(paragraph);
main.appendChild(div);

document.body.appendChild(main);
